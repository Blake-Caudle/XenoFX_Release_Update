#!/usr/bin/env python
"""
imagedb.py
Provides the image database
"""

import sqlite3
import image


class ImageDB(object):
    """ This is the image db provider """
    dbname = 'geodata.db'
    con = None

    def __init__(self):
        """ open a connection, and create the tables if they don't exist """
        try:
            self.con = sqlite3.connect(self.dbname, check_same_thread=False)
            if not self.table_exists(image.table_name):
                self.create_table(image.table_name, image.table_def)
            if not self.table_exists(image.table_old):
                self.create_table(image.table_old, image.def_old)
            if not self.table_exists(image.table_flights):
                self.create_table(image.table_flights, image.def_flights)
            if not self.table_exists(image.table_unknown):
                self.create_table(image.table_unknown, image.def_unknown)
        except sqlite3.Error, e:
            raise e

    def close(self):
        """ close the db connection """
        if self.con is not None:
            self.con.close()
            self.con = None

    def cursor(self):
        """ return a db cursor """
        if self.con is not None:
            return self.con.cursor()
        return None

    def commit(self):
        """ commit changes to the db """
        if self.con is not None:
            self.con.commit()

    def table_exists(self, tablename):
        """ determine if a table already exists """
        exists = False
        if self.con is not None:
            cur = self.con.cursor()
            sql = 'SELECT COUNT(*) FROM sqlite_master WHERE type = ? AND name = ?'
            print(sql)
            cur.execute(sql, ('table', tablename))
            self.con.commit()
            row = cur.fetchone()
            if row[0] > 0:
                exists = True
        return exists

    def create_table(self, tablename, tabledef):
        """ create a table """
        if self.con is not None:
            cur = self.con.cursor()
            sql = 'CREATE TABLE ' + tablename + ' (' + tabledef + ' )'
            print(sql)
            cur.execute(sql)
            self.con.commit()
