#!/bin/bash
#
# sui-camera V0.36
# suiFlightServer V1.4.4
#
# Zip a directory name update with the following files:
#    update.sh   <--- this file is here
#    sui-camera
#    suiFlightServer/__init__.py
#    suiFlightServer/image.py
#    suiFlightServer/imagedb.py
#    suiFlightServer/uploader.py
#    suiFlightServer/webServer.py
#
# Push the file to the Companion Computer
#    scp update.zip user@10.42.0.1:/home/user/Downloads/
#
# Make the restful api call to process the update
#    curl -d '{}' http://10.42.0.1:8080/sui/cc
#
#
SRCDIR='/home/user/Downloads/update'
DESTDIR='/root/sui'
DEPDIR="${SRCDIR}/deps"
# Stop processes we're going to update
systemctl stop sui-camera
#systemctl stop suiFlightServer
#fix systemd logging
cp -f ${SRCDIR}/journald.conf /etc/systemd/
# Update
CAMFILE="${SRCDIR}/sui-camera"
if [ -f ${CAMFILE} ]; then
	cp -f ${CAMFILE} ${DESTDIR}/ 
    chmod +x ${DESTDIR}/sui-camera
fi
SVRDIR="${SRCDIR}/suiFlightServer"
if [ -d ${SVRDIR} ]; then
	cp -f ${SVRDIR}/* ${DESTDIR}/suiFlightServer/ 
fi

rm ${DESTDIR}/suiFlightServer/px_uploader.py
rm ${DESTDIR}/suiFlightServer/px_uploader.pyc
rm ${DESTDIR}/geodata.db
rm ${DESTDIR}/geodata.db.bak
rm ${DESTDIR}/geodone.db
# Start the processes back up

dpkg -i libcurl3_7.52.1-5+deb9u9_armhf.deb
dpkg -i libcurl4-openssl-dev_7.52.1-5+deb9u9_armhf.deb

cd json-c
sh autogen.sh
./configure --prefix=/usr --disable-static
make
make install


# New installs for logging update
dpkg -i ${DEPDIR}/libxslt1.1_1.1.29-2.1_armhf.deb

easy_install ${DEPDIR}/lxml-4.3.3-py2.7-linux-armv7l.egg

pip install ${DEPDIR}/future-0.17.1.tar.gz

pip install ${DEPDIR}/pymavlink-2.3.7.tar.gz

python ${SRCDIR}/ParamUpdater.py ${SRCDIR}/update.param

VERFILE="${SRCDIR}/version"
cp -f ${VERFILE} ${DESTDIR}/ 

systemctl start sui-camera
# systemctl restart suiFlightServer
exit 0